package org.luaj.vm2;

public class LuaLong extends LuaValue {

    public final long value;

    public LuaLong(long value) {
        this.value = value;
    }

    @Override
    public int type() {
        return LuaValue.TNUMBER;
    }

    @Override
    public String typename() {
        return "long";
    }

    @Override
    public boolean isnumber() {
        return true;
    }

    @Override
    public boolean islong() {
        return true;
    }

    @Override
    public long tolong() {
        return value;
    }

    @Override
    public int toint() {
        return (int) value;
    }

    @Override
    public double todouble() {
        return (double) value;
    }

    @Override
    public LuaValue tonumber() {
        return this;
    }

    @Override
    public LuaValue add(LuaValue rhs) {
        return LuaValue.valueOf(this.value + rhs.tolong());
    }

    @Override
    public LuaValue sub(LuaValue rhs) {
        return LuaValue.valueOf(this.value - rhs.tolong());
    }

    @Override
    public LuaValue mul(LuaValue rhs) {
        return LuaValue.valueOf(this.value * rhs.tolong());
    }

    @Override
    public LuaValue div(LuaValue rhs) {
        return LuaValue.valueOf(this.value / rhs.tolong());
    }

    @Override
    public LuaValue mod(LuaValue rhs) {
        return LuaValue.valueOf(this.value % rhs.tolong());
    }

    @Override
    public LuaValue neg() {
        return LuaValue.valueOf(-this.value);
    }

    @Override
    public boolean eq_b(LuaValue val) {
        return val.islong() && this.value == val.tolong();
    }

    @Override
    public boolean lt_b(LuaValue val) {
        return this.value < val.tolong();
    }

    @Override
    public boolean lteq_b(LuaValue val) {
        return this.value <= val.tolong();
    }

    @Override
    public LuaValue concat(LuaValue rhs) {
        return LuaValue.valueOf(this.tojstring().concat(rhs.tojstring()));
    }

    @Override
    public String tojstring() {
        return Long.toString(value);
    }

    @Override
    public LuaValue tostring() {
        return LuaValue.valueOf(tojstring());
    }

    @Override
    public int hashCode() {
        return (int) (value ^ (value >>> 32));
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof LuaLong) && ((LuaLong) o).value == value;
    }
}
